# -*- encoding: utf-8 -*-
from django import forms
from agenda.models import ItemAgenda
from django.utils.translation import ugettext_lazy as _

class FormItemAgenda(forms.ModelForm):
    data = forms.DateField(
        widget=forms.DateInput(format='%d/%m/%Y'),
        input_formats=['%d/%m/%Y', '%d/%m/%y'])
    class Meta:
        model = ItemAgenda
        fields = ('titulo', 'data', 'hora', 'descricao')
        verbose_names= {'titulo':_('Título do evento'), 'data':_('Data do evento'), 'hora':_('Hora'),
            'descricao':_('Informações Adicionais'),}
